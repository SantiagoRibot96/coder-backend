import mongoose from "mongoose";

mongoose.connect("tubb")
    .then(() => console.log("Siii nos conectamos a la BD"))
    .catch((error ) => console.log("SEVEN DAYS ", error))